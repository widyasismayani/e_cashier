package com.example.e_cashier

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
